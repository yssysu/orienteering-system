
var leveldata = [
{
	"backgroundimage" : 0,
	"aliens" : "0,0,0,0,0,0,1,1,1,1,1,1"
},
{
	"backgroundimage" : 0,
	"aliens" : "0,0,0,0,0,0,1,1,1,1,1,1"
},
{
	"backgroundimage" : 0,
	"aliens" : "5,0,5,0,5,0,2,2,3,3,2,2"
},
{
	"backgroundimage" : 0,
	"aliens" : "0,1,0,1,0,1,2,2,2,2,2,2"
}
];