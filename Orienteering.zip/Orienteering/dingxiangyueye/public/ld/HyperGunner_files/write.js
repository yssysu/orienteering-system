function write(message) {
    console.log(message);
  }